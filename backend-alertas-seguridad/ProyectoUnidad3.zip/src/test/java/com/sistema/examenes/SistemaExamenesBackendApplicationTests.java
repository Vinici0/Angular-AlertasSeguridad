package com.sistema.examenes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaExamenesBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
